/****************************************************************************
 Header file for keeping track of all hardware initialization

 ****************************************************************************/
 
 void InitializePins(void);