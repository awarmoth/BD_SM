#include "EF_Framework.h"

uint8_t GetMSBitNum( uint8_t Value );


uint8_t GetClearMask( uint8_t BitNum );


uint8_t GetSetMask( uint8_t BitNum );
