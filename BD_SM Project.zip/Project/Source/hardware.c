/****************************************************************************
Module file for exectuing all hardware initialization

 ****************************************************************************/

void InitializePins(void) {
	
}
