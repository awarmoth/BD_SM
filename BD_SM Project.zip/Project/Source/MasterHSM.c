/****************************************************************************
 Module
   MasterHSM.c

 Revision
   1.0.0

 Description
   This is the Hierarchical state machine for managing the game

 Notes

 History
 When           Who     What/Why
 -------------- ---     --------
 02/16/17 21:00 asw      Began converting template to MasterHSM
****************************************************************************/
/*----------------------------- Include Files -----------------------------*/
/* include header files for this state machine as well as any machines at the
   next lower level in the hierarchy that are sub-machines to this machine
*/
#include "ES_Configure.h"
#include "ES_Framework.h"
#include "MasterHSM.h"

/*----------------------------- Module Defines ----------------------------*/

/*---------------------------- Module Functions ---------------------------*/
static ES_Event DuringStateOne( ES_Event Event);

/*---------------------------- Module Variables ---------------------------*/
// everybody needs a state variable, though if the top level state machine
// is just a single state container for orthogonal regions, you could get
// away without it
static MasterState_t CurrentState;
// with the introduction of Gen2, we need a module level Priority var as well
static uint8_t MyPriority;

/*------------------------------ Module Code ------------------------------*/
/****************************************************************************
 Function
     InitMasterSM

 Parameters
     uint8_t : the priorty of this service

 Returns
     boolean, False if error in initialization, True otherwise

 Description
     Saves away the priority,  and starts
     the top level state machine
 Notes

****************************************************************************/
bool InitMasterSM ( uint8_t Priority )
{
  ES_Event ThisEvent;

  MyPriority = Priority;  // save our priority

  ThisEvent.EventType = ES_ENTRY;
  // Start the Master State machine

  StartMasterSM( ThisEvent );

  return true;
}

/****************************************************************************
 Function
     PostMasterSM

 Parameters
     ES_Event ThisEvent , the event to post to the queue

 Returns
     boolean False if the post operation failed, True otherwise

 Description
     Posts an event to this state machine's queue
 Notes

****************************************************************************/
bool PostMasterSM( ES_Event ThisEvent )
{
  return ES_PostToService( MyPriority, ThisEvent);
}

/****************************************************************************
 Function
    RunMasterSM

 Parameters
   ES_Event: the event to process

 Returns
   ES_Event: an event to return

 Description
   the run function for the top level state machine 
 Notes
   uses nested switch/case to implement the machine.

****************************************************************************/
ES_Event RunMasterSM( ES_Event CurrentEvent )
{
   bool MakeTransition = false;/* are we making a state transition? */
   MasterState_t NextState = CurrentState;
   ES_Event EntryEventKind = { ES_ENTRY, 0 };// default to normal entry to new state
   ES_Event ReturnEvent = { ES_NO_EVENT, 0 }; // assume no error

    switch ( CurrentState )
   {
       case WaitingToStart :       // If current state is WaitingToStart
         // Execute During function for WaitingToStart. ES_ENTRY & ES_EXIT are
         // processed here allow the lower level state machines to re-map
         // or consume the event
         CurrentEvent = DuringStateOne(CurrentEvent);
         //process any events
         if ( CurrentEvent.EventType != ES_NO_EVENT ) //If an event is active
         {
					  if ( CurrentEvent.EventType == ES_START ) //If an event is active
					  {
            //If event is start
							// Execute action function for WaitingToStart: event one
							NextState = Constructing;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
						if ( CurrentEvent.EventType == ES_TEAM_SWITCH ) //If an event is active
					  {
            //If event is start
							// Execute action function for WaitingToStart: event one
							NextState = WaitingToStart;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
         }
         break;
				 
       case Constructing :       // If current state is Constructing
         // Execute During function for Constructing. ES_ENTRY & ES_EXIT are
         // processed here allow the lower level state machines to re-map
         // or consume the event
         CurrentEvent = DuringStateOne(CurrentEvent);
         //process any events
         if ( CurrentEvent.EventType != ES_NO_EVENT ) //If an event is active
         {
					  if ( CurrentEvent.EventType == ES_START ) //If an event is active
					  {
            //If event is start
							// Execute action function for Constructing: event one
							NextState = Constructing;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
						if ( CurrentEvent.EventType == ES_TEAM_SWITCH ) //If an event is active
					  {
            //If event is start
							// Execute action function for Constructing: event one
							NextState = WaitingToStart;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
         }
         break;
				 
       case GameComplete :       // If current state is GameComplete
         // Execute During function for GameComplete. ES_ENTRY & ES_EXIT are
         // processed here allow the lower level state machines to re-map
         // or consume the event
         CurrentEvent = DuringStateOne(CurrentEvent);
         //process any events
         if ( CurrentEvent.EventType != ES_NO_EVENT ) //If an event is active
         {
					  if ( CurrentEvent.EventType == ES_START ) //If an event is active
					  {
            //If event is start
							// Execute action function for GameComplete: event one
							NextState = Constructing;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
						if ( CurrentEvent.EventType == ES_TEAM_SWITCH ) //If an event is active
					  {
            //If event is start
							// Execute action function for GameComplete: event one
							NextState = WaitingToStart;//Decide what the next state will be
							// for internal transitions, skip changing MakeTransition
							MakeTransition = true; //mark that we are taking a transition
							// optionally, consume or re-map this event for the upper
							// level state machine
							ReturnEvent.EventType = ES_NO_EVENT;
						}
         }
         break;
				 // repeat state pattern as required for other states
    }
    //   If we are making a state transition
    if (MakeTransition == true)
    {
       //   Execute exit function for current state
       CurrentEvent.EventType = ES_EXIT;
       RunMasterSM(CurrentEvent);

       CurrentState = NextState; //Modify state variable

       // Execute entry function for new state
       // this defaults to ES_ENTRY
       RunMasterSM(EntryEventKind);
     }
   // in the absence of an error the top level state machine should
   // always return ES_NO_EVENT, which we initialized at the top of func
   return(ReturnEvent);
}
/****************************************************************************
 Function
     StartMasterSM

 Parameters
     ES_Event CurrentEvent

 Returns
     nothing

 Description
     Does any required initialization for this state machine
 Notes


****************************************************************************/
void StartMasterSM ( ES_Event CurrentEvent )
{
  // if there is more than 1 state to the top level machine you will need 
  // to initialize the state variable
  CurrentState = WaitingToStart;
  // now we need to let the Run function init the lower level state machines
  // use LocalEvent to keep the compiler from complaining about unused var
  RunMasterSM(CurrentEvent);
  return;
}


/***************************************************************************
 private functions
 ***************************************************************************/

static ES_Event DuringStateOne( ES_Event Event)
{
    ES_Event ReturnEvent = Event; // assme no re-mapping or comsumption

    // process ES_ENTRY, ES_ENTRY_HISTORY & ES_EXIT events
    if ( (Event.EventType == ES_ENTRY) ||
         (Event.EventType == ES_ENTRY_HISTORY) )
    {
        // implement any entry actions required for this state machine
        
        // after that start any lower level machines that run in this state
        //StartLowerLevelSM( Event );
        // repeat the StartxxxSM() functions for concurrent state machines
        // on the lower level
    }
    else if ( Event.EventType == ES_EXIT )
    {
        // on exit, give the lower levels a chance to clean up first
        //RunLowerLevelSM(Event);
        // repeat for any concurrently running state machines
        // now do any local exit functionality
      
    }else
    // do the 'during' function for this state
    {
        // run any lower level state machine
        // ReturnEvent = RunLowerLevelSM(Event);
      
        // repeat for any concurrent lower level machines
      
        // do any activity that is repeated as long as we are in this state
    }
    // return either Event, if you don't want to allow the lower level machine
    // to remap the current event, or ReturnEvent if you do want to allow it.
    return(ReturnEvent);
}
